# Elastic Universal Profiling host-agent
This chart installs the host-agent in your Kubernetes cluster.
The agent is deployed as a DaemonSet and requires a `privileged` security context as it needs access to the nodes' kernel features.

## Quick start installation

* Add the Helm repository hosting the Optimyze charts, you only need to run this when first installing:
  ```bash
  helm repo add elastic https://helm.elastic.co
  ```

* Fetch the `projectID`, `secretToken` and `collectionAgentHostPort` values visible in Kibana when using
  Universal Profiling.
  
  Use the values in the following command, replacing the placeholders:

  ```bash
  helm install --create-namespace -n=universal-profiling universal-profiling-agent \
  --set "projectID=<projectID>,secretToken=<secretToken>" \
  --set "collectionAgentHostPort=<collectionAgent> \
  elastic/pf-host-agent
  ```

## Customizing values

For more complex deployments, you may want to customize Helm values.
You can list the possible values using:

```bash
helm show values elastic/pf-host-agent
```

The most notable configuration knobs are `nodeSelector` and `tolerations` to deploy Prodfiler Host Agent
only to a subset of nodes in your cluster.
