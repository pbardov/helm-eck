/* builds the authentication to DockerHub */
{{- define "imagePullSecret" }}
{{- with .Values.registry }}
{{- printf "{\"auths\":{\"%s\":{\"username\":\"%s\",\"password\":\"%s\",\"auth\":\"%s\"}}}" .url (required "registry.username can't be empty!" .username ) (required "registry.password can't be empty!" .password) (printf "%s:%s" .username .password | b64enc) | b64enc }}
{{- end }}
{{- end }}

/* builds the image name or returns the default for backward compatibility */
{{- define "imageFullName" }}
{{- if .Values.image }}
{{- with .Values.image }}
{{- if .baseUrl }}
{{- printf "%s/%s/%s" .baseUrl .repository .name }}
{{- else }}
{{- printf "%s/%s" .repository .name }}
{{- end }}
{{- end }}
{{- else }}optimyze/pf-host-agent
{{- end }}
{{- end }}

/*

Configures host-agent version: since the introduction of breaking changes in v3,
we let users adopt by default the "stable" tag, pointing to v2.
From v3 onwards, if "image.tag" is not provided, the same version of Kibana will be used.
*/
{{- define "host-agent-version" }}
{{- printf "%s" ( .Values.image.tag | default .Chart.AppVersion ) }}
{{- end }}

{{- define "configmap-agent-version" }}
{{- printf "%s" ( .Values.image.tag | default .Chart.AppVersion | lower ) }}
{{- end }}
