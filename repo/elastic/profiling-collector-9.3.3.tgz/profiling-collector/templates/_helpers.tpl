/* builds the Docker registry secret */
{{- define "imagePullSecret" }}
{{- with .Values.registry }}
{{- printf "{\"auths\":{\"%s\":{\"username\":\"%s\",\"password\":\"%s\",\"auth\":\"%s\"}}}" .url (required "registry.username can't be empty!" .username ) (required "registry.password can't be empty!" .password) (printf "%s:%s" .username .password | b64enc) | b64enc }}
{{- end }}
{{- end }}

/* builds the image name */
{{- define "imageFullName" }}
{{- with .image }}
{{- if .url }}
{{- printf "%s/%s/%s" .url .repository .name }}
{{- else }}
{{- printf "%s/%s" .repository .name }}
{{- end }}
{{- end }}
{{- end }}
