# Elastic Universal Profiling Symbolizer

The symbolizer is the asynchronous component that processes native frames collected by the Universal Profiling agents.
It is a stateless service that reads data from Elasticsearch and enriches them with debug symbol information.

The debug symbol information is retrieved from the debug symbol global system, which is a separate component hosted
as an object store with S3 compatible API.

### Configuration

To deploy on Kubernetes, you may re-use an existing YAML config file used to deploy via binary or OCI image.
Pass the path to the file as a value to the `-f` flag of `helm install` or `helm upgrade`, together
with a second (optional) values file containing the Kubernetes-specific configuration properties.

For example, to deploy the symbolizer using the default values, you can run:

```bash
helm repo add elastic https://helm.elastic.co
helm install -f /path/to/config/pf-elastic-symbolizer.yml pf-elastic-symbolizer elastic/profiling-symbolizer
```

If instead you want to customize some Kubernetes properties, such as `resources` or `ingress`, you can run
the following commands:

```bash
helm repo add elastic https://helm.elastic.co
helm install -f /path/to/config/pf-elastic-symbolizer.yml \
  --set "resources.limit.memory=8Gi" pf-elastic-symbolizer elastic/profiling-symbolizer
```

or

```bash
helm repo add elastic https://helm.elastic.co
helm install -f /path/to/config/pf-elastic-symbolizer.yml -f values.yaml \
  pf-elastic-symbolizer elastic/profiling-symbolizer
```
